package com.guard.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var st: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 100, 40, 40) }
        fun et(hint: String, key: String, pw: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, ""))
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            root.addView(this)
        }
        val from = et("Gmail address (bhejne wala)", "from")
        val pass = et("Gmail App Password (16 letters)", "pass", true)
        val to = et("Photo kis email par aye (khali = wohi)", "to")
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() }; root.addView(this) }
        fun save() {
            val pw = pass.text.toString().replace(" ", "")
            p.edit().putString("from", from.text.toString().trim()).putString("pass", pw)
                .putString("to", to.text.toString().trim()).apply()
            if (pw.length != 16) Toast.makeText(this, "Dhyan: App Password 16 letters ka hota hai, aap ka ${pw.length} ka hai", Toast.LENGTH_LONG).show()
        }

        btn("1. Permissions do (camera, location, notification)") {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2. Device Admin ON karo") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
        }
        btn("3. Accessibility ON karo (power menu/WiFi/airplane block)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Installed apps > Guard > ON", Toast.LENGTH_LONG).show()
        }
        btn("4. Battery: Unrestricted karo") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("5. Protection START") {
            save(); p.edit().putBoolean("on", true).apply()
            startForegroundService(Intent(this, GuardService::class.java))
            Toast.makeText(this, "Protection chalu", Toast.LENGTH_SHORT).show()
        }
        btn("Protection STOP") {
            p.edit().putBoolean("on", false).apply()
            stopService(Intent(this, GuardService::class.java))
        }
        btn("TEST: abhi photo + email bhejo") {
            save()
            val s = GuardService.instance
            if (s == null) Toast.makeText(this, "Pehle Protection START karo", Toast.LENGTH_LONG).show()
            else { GuardService.last = 0; s.snap(); Toast.makeText(this, "Bhej raha hoon, 1 minute baad Status refresh karo", Toast.LENGTH_LONG).show() }
        }
        btn("STATUS refresh") { refresh() }
        st = TextView(this).apply { textSize = 15f; setPadding(0, 30, 0, 0) }
        root.addView(st)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun yn(b: Boolean) = if (b) "HAAN" else "NAHI"

    private fun refresh() {
        val p = getSharedPreferences("cfg", 0)
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        val cam = checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val loc = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        st.text = "Device Admin: ${yn(admin)}\nAccessibility ON: ${yn(acc)}\nCamera permission: ${yn(cam)}\n" +
            "Location permission: ${yn(loc)}\nProtection chal rahi: ${yn(GuardService.instance != null)}\n" +
            "Aakhri ghalat PIN pakda: ${p.getString("evt", "kabhi nahi")}\n" +
            "Aakhri block (power/wifi): ${p.getString("blk", "kabhi nahi")}\n" +
            "Aakhri email: ${p.getString("last", "koi nahi")}"
    }
}
