package com.guard.app

import android.content.Context
import android.location.Location
import android.os.Build
import java.io.File
import java.util.Date
import java.util.Properties
import javax.activation.DataHandler
import javax.activation.FileDataSource
import javax.mail.*
import javax.mail.internet.*

object Mailer {
    fun send(c: Context, photo: File?, loc: Location?) {
        val p = c.getSharedPreferences("cfg", 0)
        val user = p.getString("from", "") ?: ""
        val pass = p.getString("pass", "") ?: ""
        val to = p.getString("to", "").let { if (it.isNullOrBlank()) user else it }
        val props = Properties().apply {
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "465")
            put("mail.smtp.ssl.enable", "true")
            put("mail.smtp.auth", "true")
            put("mail.smtp.connectiontimeout", "15000")
            put("mail.smtp.timeout", "20000")
        }
        val session = Session.getInstance(props, object : Authenticator() {
            override fun getPasswordAuthentication() = PasswordAuthentication(user, pass)
        })
        val where = if (loc != null)
            "Location: https://maps.google.com/?q=${loc.latitude},${loc.longitude} (accuracy ${loc.accuracy.toInt()}m)"
        else "Location nahi mili."
        val body = "Kisi ne ghalat PIN dala.\nWaqt: ${Date()}\nPhone: ${Build.MANUFACTURER} ${Build.MODEL}\n$where" +
            if (photo == null) "\nPhoto nahi aa saki." else ""
        val text = MimeBodyPart().apply { setText(body) }
        val mp = MimeMultipart().apply { addBodyPart(text) }
        if (photo != null) mp.addBodyPart(MimeBodyPart().apply {
            dataHandler = DataHandler(FileDataSource(photo)); fileName = photo.name
        })
        val msg = MimeMessage(session).apply {
            setFrom(InternetAddress(user))
            setRecipients(Message.RecipientType.TO, InternetAddress.parse(to))
            subject = "ALERT: Ghalat PIN - Intruder"
            setContent(mp)
        }
        Transport.send(msg)
    }

    private fun note(c: Context, t: String) =
        c.getSharedPreferences("cfg", 0).edit().putString("last", t).apply()

    fun sendWithRetry(c: Context, photo: File?, loc: Location?) {
        repeat(8) { n ->
            try {
                send(c, photo, loc)
                note(c, "Email gaya OK: ${Date()}")
                return
            } catch (e: AuthenticationFailedException) {
                note(c, "Email FAIL: Gmail login ghalat. 16 letter ka App Password dalein.")
                return
            } catch (e: Exception) {
                note(c, "Email FAIL (${n + 1}/8): ${e.message}")
                Thread.sleep(30000)
            }
        }
    }
}
