package com.guard.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Date

class LockGuardService : AccessibilityService() {
    private val bad = setOf(
        "power off", "restart", "shut down", "shutdown", "reboot", "power off & restart",
        "airplane mode", "flight mode", "airplane", "wi-fi", "wifi", "internet", "mobile data", "mobile network"
    )
    private var lastScan = 0L

    override fun onServiceConnected() {
        getSharedPreferences("cfg", 0).edit().putString("acc", Date().toString()).apply()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val p = getSharedPreferences("cfg", 0)
        if (!p.getBoolean("on", false)) return
        if (!getSystemService(KeyguardManager::class.java).isKeyguardLocked) return
        val cls = e.className?.toString() ?: ""
        var hit = cls.contains("GlobalActions", true) || cls.contains("PowerMenu", true)
        val now = System.currentTimeMillis()
        if (!hit && now - lastScan > 120) {
            lastScan = now
            hit = scan(rootInActiveWindow, 0)
            if (!hit) for (w in windows) { if (scan(w.root, 0)) { hit = true; break } }
        }
        if (hit) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            performGlobalAction(GLOBAL_ACTION_HOME)
            p.edit().putString("blk", Date().toString()).apply()
        }
    }

    private fun scan(n: AccessibilityNodeInfo?, d: Int): Boolean {
        if (n == null || d > 14) return false
        val t = n.text?.toString()?.trim()?.lowercase()
        val c = n.contentDescription?.toString()?.trim()?.lowercase()
        if ((t != null && t in bad) || (c != null && c in bad)) return true
        for (i in 0 until n.childCount) if (scan(n.getChild(i), d + 1)) return true
        return false
    }

    override fun onInterrupt() {}
}
