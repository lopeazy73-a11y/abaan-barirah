package com.guard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import java.util.Date

class AdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        val p = context.getSharedPreferences("cfg", 0)
        p.edit().putString("evt", Date().toString()).apply()
        if (!p.getBoolean("on", false)) return
        val s = GuardService.instance
        if (s != null) s.snap()
        else Thread { Mailer.sendWithRetry(context.applicationContext, null, null) }.start()
    }
}
